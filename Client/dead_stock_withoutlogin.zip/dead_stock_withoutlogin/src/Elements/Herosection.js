import React from "react";
import '../Assets/Herosection.css';

function Hero() {
    return (
      <div className="hero-container">
          {/* <img src="https://www.pexels.com/photo/cargo-container-lot-906494/" className='image'/> */}
          <h1>Managing your Warehouse</h1>
          <h3>is now our <span>Responsibility</span></h3>
          
      </div>
    );
  }
  
  export default Hero;